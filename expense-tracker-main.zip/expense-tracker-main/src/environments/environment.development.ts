export const environment = {
    production:true,
    apiUrl:'https://expense-tracker-t3cs.onrender.com/v1/api/',
};
