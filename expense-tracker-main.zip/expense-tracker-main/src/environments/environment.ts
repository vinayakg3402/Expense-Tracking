export const environment = {
    production:false,
    apiUrl:'https://expense-tracker-t3cs.onrender.com/v1/api/',
};
